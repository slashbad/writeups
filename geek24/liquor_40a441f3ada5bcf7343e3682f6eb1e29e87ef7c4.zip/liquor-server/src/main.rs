use std::{
    collections::HashMap, fs, io, os::unix::process::CommandExt, process::Command, time::Duration,
};

use axum::{
    http::StatusCode,
    response::Html,
    routing::{get, post},
    Json, Router,
};
use nix::{
    errno::Errno,
    unistd::{setgid, setgroups, setuid},
};
use serde::{Deserialize, Serialize};
use wait_timeout::ChildExt as _;

#[tokio::main]
async fn main() {
    // build our application with a route
    let app = Router::new()
        .route("/", get(root))
        .route("/liquor", post(liquor));

    // run our app with hyper, listening globally on port 3000
    let listener = tokio::net::TcpListener::bind("0.0.0.0:3000").await.unwrap();
    axum::serve(listener, app).await.unwrap();
}

// basic handler that responds with a static string
async fn root() -> Html<&'static str> {
    Html(include_str!("../static/index.html"))
}

async fn liquor(Json(payload): Json<LiquorInputs>) -> (StatusCode, Json<LiquorOutput>) {
    if let Err(e) = fs::write("./words", payload.words) {
        return (
            StatusCode::INTERNAL_SERVER_ERROR,
            Json(LiquorOutput(e.to_string() + " when writing words. ")),
        );
    }
    if let Err(e) = fs::write("./truth", "") {
        return (
            StatusCode::INTERNAL_SERVER_ERROR,
            Json(LiquorOutput(e.to_string() + " when clearing truth. ")),
        );
    }
    let mut cmd = &mut Command::new("./liquor");
    cmd = cmd.envs(&payload.envs);
    cmd = unsafe {
        cmd.pre_exec(|| {
            let emap = |e: Errno| io::Error::new(io::ErrorKind::Other, e.to_string());
            setgroups(&[]).map_err(emap)?;
            setgid(1000.into()).map_err(emap)?;
            setuid(1000.into()).map_err(emap)
        })
    };
    let mut child = cmd.spawn().unwrap();
    let one_sec = Duration::from_secs(1);
    if child.wait_timeout(one_sec).unwrap().is_none() {
        // child hasn't exited yet
        // child.kill().unwrap();
        let _ = Command::new("/usr/bin/pkill").args(["-u", "ctf"]).status();
        let _ = child.wait().unwrap().code();
        return (
            StatusCode::INTERNAL_SERVER_ERROR,
            Json(LiquorOutput("Timeout. ".to_owned())),
        );
    };
    let r = fs::read_to_string("./truth");
    match r {
        Ok(s) => (StatusCode::OK, Json(LiquorOutput(s))),
        Err(e) => (
            StatusCode::INTERNAL_SERVER_ERROR,
            Json(LiquorOutput(e.to_string())),
        ),
    }
}

#[derive(Deserialize)]
struct LiquorInputs {
    words: String,
    envs: HashMap<String, String>,
}

#[derive(Serialize)]
struct LiquorOutput(String);
